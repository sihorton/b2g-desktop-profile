(function(window) {

  function Lib() {

  }

  Lib.prototype = {
    method: function() {

    }
  };

  window.Lib = Lib;

}(this));
