
'use strict';

var optionDefaults = {
  'plantype': 'prepaid',
  'tracking_period': 'never',
  'reset_time': 1,
  'lowlimit': true,
  'lowlimit_threshold': 5
};
