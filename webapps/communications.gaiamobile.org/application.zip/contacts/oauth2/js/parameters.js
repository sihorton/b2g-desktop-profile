var fb = window.fb || {};
fb.oauthflow = window.fb.oauthflow || {};

fb.oauthflow.params = {
  redirectURI:
    'http://intense-tundra-4122.herokuapp.com/fbowd/oauth2/flow.html',
  loginPage:
    'https://m.facebook.com/dialog/oauth/?',
  applicationId:
    '323630664378726',
  contactsAppOrigin:
    'app://communications.gaiamobile.org',
  redirectMsg:
    'http://intense-tundra-4122.herokuapp.com/fbowd/dialogs_end.html'
};
