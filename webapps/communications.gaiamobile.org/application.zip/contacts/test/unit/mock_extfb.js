'use strict';

var MockExtFb = {
  importFB: function() {}
};
