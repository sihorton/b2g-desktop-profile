function MockChromeEvent(detail) {
  this.type = 'mozChromeEvent';
  this.detail = detail;
}
