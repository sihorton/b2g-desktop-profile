The `serviceproviders.xml` file comes from the [Gnome Service Providers
Database](https://live.gnome.org/NetworkManager/MobileBroadband/ServiceProviders),
and the following patch has been applied:

* https://bugzilla.gnome.org/show_bug.cgi?id=681745

