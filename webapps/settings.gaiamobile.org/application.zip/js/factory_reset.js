/* -*- Mode: js; js-indent-level: 2; indent-tabs-mode: nil -*- */
/* vim: set shiftwidth=2 tabstop=2 autoindent cindent expandtab: */

'use strict';

window.addEventListener('localized', function SettingsFactoryReset(evt) {

  var _ = navigator.mozL10n.get;

  function factoryReset() {
    //console.warn('+++ factory reset+++');
  }

  var resetButton = document.getElementById('reset-phone');
  if (resetButton) {
    resetButton.addEventListener('click', function reset_click(evt) {

      //XXX: need to refine this part after the visual design is done
      var msg = _('reset-warning-1') + '\n' +
                _('reset-warning-2');

      var response = window.confirm(msg);
      if (response)
        factoryReset();
    });
  }
});
