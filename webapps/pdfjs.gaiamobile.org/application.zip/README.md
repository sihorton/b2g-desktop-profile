Please **DO NOT** make any changes to any files in the content directory.
pdf.js is maintained in a seperate repository, they should all come from upstream.

https://github.com/mozilla/pdf.js
